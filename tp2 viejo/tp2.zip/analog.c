#define _POSIX_C_SOURCE 200809L  // Para strdup() y getline
#define _XOPEN_SOURCE
#include <time.h>
#define TIME_FORMAT "%FT%T%z"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "strutil.h"
#include "hash.h"
#include "abb.h"
#include "heap.h"
#include "lista.h"

#define DOS_THRESHOLD 5
#define DOS_TIME 2.0



//==========|Structs|============
typedef struct request {
	char* ip;
	time_t hora;
	char* metodo;
	char* recurso;	
}request_t;

typedef struct visita {
	char* recurso;
	int cant_visitas;
}visita_t;
//==========|Wrappers|===========
void lista_destruir_wrapper(void* lista){
	lista_t* lista_ = lista;
	lista_destruir(lista_,NULL);
}
//=========|Func aux|=========
time_t iso8601_to_time(const char* iso8601){
    struct tm bktime = { 0 };
    strptime(iso8601, TIME_FORMAT, &bktime);
    return mktime(&bktime);
}

request_t* request_crear(char* ip, time_t hora,char* metodo, char* recurso){
	request_t* request = malloc(sizeof(request_t));
	if(!request)
		return NULL;
	request->ip = ip;
	request->hora = hora;
	request->metodo = metodo;
	request->recurso = recurso;
	return request;
}

void request_destruir(void* request){
	request_t* req = request;
	free(req->ip);
	//free(req->hora);
	free(req->metodo);
	free(req->recurso);
	free(request);
}

int comparar_ips(const char* ip1, const char* ip2){
    int flag = 0;
    char** ip1_partes = split(ip1, '.');
    int ip1_campos[4];
    ip1_campos[0] = atoi(ip1_partes[0]);
    ip1_campos[1] = atoi(ip1_partes[1]);
    ip1_campos[2] = atoi(ip1_partes[2]);
    ip1_campos[3] = atoi(ip1_partes[3]);
    char** ip2_partes = split(ip2, '.');
    int ip2_campos[4];
    ip2_campos[0] = atoi(ip2_partes[0]);
    ip2_campos[1] = atoi(ip2_partes[1]);
    ip2_campos[2] = atoi(ip2_partes[2]);
    ip2_campos[3] = atoi(ip2_partes[3]);
 
    for(int i = 0; i < 4; i++){
        if(ip1_campos[i] > ip2_campos[i]){
            flag = 1;
            break;
        }
           
        if(ip1_campos[i] < ip2_campos[i]){
            flag = -1;
            break;
        }
    }
    free_strv(ip1_partes);
    free_strv(ip2_partes);
 
    return flag;
}
//Recorre una lista de time_t y devuelve true si es DoS. 
bool acceso_es_dos(lista_t* lista_tiempo){
	lista_iter_t* iter1 = lista_iter_crear(lista_tiempo);
	lista_iter_t* iter2 = lista_iter_crear(lista_tiempo);
	int i = 0;
	while(i<DOS_THRESHOLD-1){ //Avanzo el iter2 N posiciones
		lista_iter_avanzar(iter2);
		
		if(lista_iter_al_final(iter2)){
			lista_iter_destruir(iter1);
			lista_iter_destruir(iter2);
			return false;
		}
		i++;
	}
	while(!lista_esta_vacia(lista_tiempo)){
	
		time_t tiempo1 = (time_t)lista_iter_ver_actual(iter1);
		time_t tiempo2 = (time_t)lista_iter_ver_actual(iter2);
		if(difftime(tiempo2,tiempo1) < 2.0){

			lista_iter_destruir(iter1);
			lista_iter_destruir(iter2);
			return true;
		}
		lista_iter_avanzar(iter1);
		lista_iter_avanzar(iter2);
		if(lista_iter_al_final(iter2))
			break;
		
	}
	lista_iter_destruir(iter1);
	lista_iter_destruir(iter2);
	return false;
}


bool guardar_ip_abb(abb_t* arbol, request_t* request){
	if(!abb_guardar(arbol,request->ip,NULL))
		return false;
	return true;
}

bool hash_guardar_request(hash_t* hash_tiempos, const char* ip, time_t tiempo){
	if(!hash_tiempos)
		return false;

	if(hash_pertenece(hash_tiempos,ip)){ //si la ip ya esta guardada
		
		lista_t* lista_tiempos_ip = hash_obtener(hash_tiempos,ip); //obtengo la lista de tiempos de esa ip
		lista_insertar_ultimo(lista_tiempos_ip,(void*)tiempo); //inserto el nuevo tiempo al final
		return true;
	}
	if(!hash_pertenece(hash_tiempos,ip)){ //Si la ip no pertenece al hash creo lista nueva y la guardo
		lista_t* new_lista = lista_crear();
		lista_insertar_ultimo(new_lista, (void*)tiempo);
		hash_guardar(hash_tiempos,ip,new_lista);
		return true;
	}
	return false;
}
void chequear_dos(hash_t* hash_tiempos,abb_t* abb_ips_dos){
	hash_iter_t* iter = hash_iter_crear(hash_tiempos);
	while(!hash_iter_al_final(iter)){
		const char* ip = hash_iter_ver_actual(iter);
		lista_t* lista = hash_obtener(hash_tiempos,ip);
		if(acceso_es_dos(lista)){
			abb_guardar(abb_ips_dos,ip,NULL);
		}
		hash_iter_avanzar(iter);
	}
	hash_iter_destruir(iter);
}
	

bool visitar_imprimir_dos(const char* clave, void* dato,void* extra){
	fprintf(stdout,"DoS: %s\n",clave);
	return true;
}
void guardar_url(hash_t* hash_visitas, char* recurso){

    if(!hash_pertenece(hash_visitas,recurso)){
		int* cant = malloc(sizeof(int));
		*cant = 1;
        hash_guardar(hash_visitas,recurso,cant);
    }else{
        int* cant = hash_obtener(hash_visitas,recurso);
        *cant +=1;
    }        
}

int comparar_visitas(const void* vis1_void, const void* vis2_void){
    const visita_t* vis1 = vis1_void;
    const visita_t* vis2 = vis2_void;
    return vis2->cant_visitas - vis1->cant_visitas; //funcion al reves para heap de minimos
}
bool imprimir_ip(const char* clave){
    printf("\t%s\n",clave);
    return true;
}
bool visitar_imprimir(const char* clave, void* dato,void* extra){
	char** rango = extra;
	if(!(comparar_ips(clave,rango[0])<0) && !(comparar_ips(clave,rango[1])>0))
		printf("\t%s\n",clave);
	return true;
}

void imprimir_url_maximos(heap_t* mas_visitados){
    if (heap_esta_vacio(mas_visitados))
    	return;
    visita_t* dato = heap_desencolar(mas_visitados);
    imprimir_url_maximos(mas_visitados);
    printf("\t%s - %d\n",dato->recurso, dato->cant_visitas);
    free(dato);
}
visita_t* visita_crear(char* recurso){
	visita_t* visita = malloc(sizeof(visita_t));
	if(!visita)
		return NULL;
	visita->recurso = recurso;
	visita->cant_visitas = 0;
	return visita;
}
void visita_destruir(visita_t* vis){
	free(vis->recurso);
	free(vis);
}
void visita_destruir_wrapper(void* visita){
	visita_destruir((visita_t*) visita);
}

//==============================================|FUNCIONES PRINCIPALES|=============
bool agregar_archivo(char* filename, abb_t* abb_ips, hash_t* hash_urls){
	FILE* archivo = fopen(filename,"r");
	if(archivo == NULL){
		//fprintf(stderr,"Fallo carga de archivo\n");
		return false;
	}
	hash_t* hash_tiempos = hash_crear(lista_destruir_wrapper); //guardo una lista que contiene los tiempos de acceso por ip
	if(!hash_tiempos){
		fclose(archivo);
		return false;
	}
	abb_t* abb_ips_dos = abb_crear(comparar_ips,free);
	if(!abb_ips_dos){
		fclose(archivo);
		hash_destruir(hash_tiempos);
		return false;
		
	}
	char* linea = NULL; size_t size = 0; ssize_t leidos;
	while((leidos  = getline(&linea,&size,archivo))>0){
		linea[leidos-1] = '\0';
		
		char** lin_split = split(linea,'\t');
		char* ip = lin_split[0];
		char* time = lin_split[1];
		//char* metodo = lin_split[2];
		char* recurso = lin_split[3];
		
		//request_t* request = request_crear(ip,iso8601_to_time(time),metodo,recurso);

		if(!abb_pertenece(abb_ips,ip))
			abb_guardar(abb_ips,ip,NULL);
			
		guardar_url(hash_urls,recurso);
		
		hash_guardar_request(hash_tiempos,ip,iso8601_to_time(time));
		
		free_strv(lin_split);
		//request_destruir(request);
	}
	chequear_dos(hash_tiempos,abb_ips_dos);
	
	if(abb_cantidad(abb_ips_dos) != 0){ //Si el abb de DoS no esta vacio recorre inorder con visitar que imprime las ips
		abb_in_order(abb_ips_dos,visitar_imprimir_dos,NULL);

	}
	
	abb_destruir(abb_ips_dos);
	hash_destruir(hash_tiempos);
	free(linea);
	fclose(archivo);
	fprintf(stdout,"OK\n");
	return true;
	

}

bool ver_visitantes(abb_t* abb_ips, char* desde, char* hasta){
    if(abb_cantidad(abb_ips) == 0)
    	return false;
    char** rango = malloc(sizeof(char*)*2);
    rango[0] = desde;
    rango[1] = hasta; 
    printf("Visitantes:\n");
    abb_in_order(abb_ips, visitar_imprimir,(void*)rango);
    fprintf(stdout,"OK\n" );
    free(rango);
    return true;
}

void ver_mas_visitados(size_t n, hash_t* url_visitas){
    
    heap_t* mas_visitados = heap_crear(comparar_visitas);
    hash_iter_t* hash_iter = hash_iter_crear(url_visitas);
 
    for(int i = 0; i < n; i++){
        if(hash_iter_al_final(hash_iter))
        	break;
        	
        visita_t* visita = malloc(sizeof(visita_t));
        visita->recurso = strdup(hash_iter_ver_actual(hash_iter));
        visita->cant_visitas = *(int*)hash_obtener(url_visitas, visita->recurso);
        heap_encolar(mas_visitados, visita);
        hash_iter_avanzar(hash_iter);
    }
    
    while(!hash_iter_al_final(hash_iter)){
        visita_t* visita = malloc(sizeof(visita_t));
        visita->recurso = (char*)hash_iter_ver_actual(hash_iter);
        visita->cant_visitas = *(int*)hash_obtener(url_visitas, visita->recurso);
        visita_t* tope = (visita_t*)heap_ver_max(mas_visitados);
        
        if(visita->cant_visitas > tope->cant_visitas){
            heap_desencolar(mas_visitados);
            //free(vis->recurso);
            free(tope);
            heap_encolar(mas_visitados, visita);
        }
        else{
        //	free(visita->recurso);
        	free(visita);
        }	
        hash_iter_avanzar(hash_iter);
    }
    hash_iter_destruir(hash_iter);
    fprintf(stdout,"Sitios más visitados:\n");
    imprimir_url_maximos(mas_visitados);
    printf("%s\n","OK" );
    heap_destruir(mas_visitados, visita_destruir_wrapper);
}

//=====================|Interfaz|=======================
void kill(abb_t* abb_ips,hash_t* hash_urls){
	abb_destruir(abb_ips);
	hash_destruir(hash_urls);
}
int interfaz(char** args, abb_t* abb_ips, hash_t* hash_urls){
		int t2err = 0;
		char* comando = args[0];
		if(strcmp(comando,"agregar_archivo") == 0){
			if(!args[1]){
				fprintf(stderr,"Error en el comando %s\n",comando);
				t2err++;
				free_strv(args);
				return t2err;
			}
			char* archivo = args[1];
			//agregar_archivo(archivo,abb_ips,hash_urls);
			if(!agregar_archivo(archivo,abb_ips,hash_urls)){
				fprintf(stderr,"Error en el comando agregar_archivo\n");
				t2err++;
				free_strv(args);
				return t2err;		
			}
		}
		
		else if(strcmp(comando,"ver_visitantes")==0){
			if(!args[1] || !args[2]){
				fprintf(stderr,"Error en el comando %s\n",comando);
				t2err++;
				free_strv(args);
				return t2err;	
			}
			if(!ver_visitantes(abb_ips,args[1],args[2])){
				fprintf(stderr,"Error en el comando %s\n",comando);
				t2err++;
				free_strv(args);
				return t2err;	
			}
		}
		
		else if(strcmp(comando,"ver_mas_visitados")==0){
			if(!args[1]){
				fprintf(stderr,"Error en el comando %s\n",comando);
				t2err++;
				free_strv(args);
				return t2err;	
			}
			ver_mas_visitados(atoi(args[1]),hash_urls);
			free_strv(args);
			return t2err;
		}
		
		else{
			fprintf(stderr,"Error en el comando\n");
			t2err++;
			free_strv(args);
			return t2err;
						
		}
		free_strv(args);
		return t2err;
		
}



