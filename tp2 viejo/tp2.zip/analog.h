#ifndef ANALOGS_H
#define ANALOGS_H


#include <time.h>
#define TIME_FORMAT "%FT%T%z"
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "strutil.h"
#include "hash.h"
#include "abb.h"
#include "heap.h"
#include "lista.h"

int comparar_ips(const char* ip1, const char* ip2);

bool acceso_es_dos(lista_t* lista_tiempo);

bool hash_guardar_request(hash_t* hash_tiempos, const char* ip, time_t tiempo);

void chequear_dos(hash_t* hash_tiempos,abb_t* abb_ips_dos);


void guardar_url(hash_t* hash_visitas, char* recurso);
void visita_destruir_wrapper(void* visita);
int comparar_visitas(const void* vis1_void, const void* vis2_void);
bool agregar_archivo(char* filename, abb_t* abb_ips, hash_t* hash_urls);
bool ver_visitantes(abb_t* abb_ips, char* desde, char* hasta);
void ver_mas_visitados(size_t n, hash_t* url_visitas);

int interfaz(char** args, abb_t* abb_ips, hash_t* hash_urls);


#endif //ANALOG_H
