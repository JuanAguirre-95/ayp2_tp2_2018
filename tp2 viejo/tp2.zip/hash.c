#define _POSIX_C_SOURCE  200809L
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "hash.h"
#include "lista.h"

#include "hashing.h"


#define FACTOR_REDIMENSION_SUP 2//Cuanto va a ser el tamanio de la redimension (ej: 2*tamanio del hash)
#define FACTOR_REDIMENSION_INF 4//Por cuanto vamos a dividir el tamaño del hash
#define HASH_TAM_TABLA 199
#define FACTOR_CARGA_INF 0.25
#define FACTOR_CARGA_SUP 0.75 //Cual va a ser la relacion entre cant_elem/tamanio del hash para llamar a una redimension

/*			Definicion de las estructuras			*/
struct hash{
	lista_t** listas;
	size_t cantidad_elem;
	size_t tamanio_tabla;	
	hash_destruir_dato_t destructor_dato;
};

typedef struct hash_nodo{
	char* clave;
	void* dato;
}hash_nodo_t;

struct hash_iter{
	const hash_t* hash; 
	lista_iter_t* lista_iter;    	
	size_t lista_actual;	
};


hash_nodo_t* crear_hash_nodo(const char* clave, void* valor){
	hash_nodo_t* nodo = malloc(sizeof(hash_nodo_t));
	if(!nodo){
		return NULL;
	}	
	nodo->clave = strdup(clave);
	if(!nodo->clave){
		return NULL; 	
	}
	nodo->dato = valor;	
	return nodo;
}
/*			Definicion de primitivas			*/

lista_t** inicializar_listas(size_t tam){
	lista_t** listas = malloc(sizeof(lista_t*)*tam);
	if(!listas){
		return NULL;
	}
	for(int i=0;i<tam;i++){
		lista_t* lista = lista_crear();							
		if(!lista){   
			free(listas);
			return NULL;
		}	
		listas[i] = lista;	
	} 
	return listas;
}

void hash_nodo_destruir(hash_nodo_t* nodo,hash_destruir_dato_t destruir_dato){		
	if(destruir_dato){
		destruir_dato(nodo->dato);
	}
	free(nodo->clave);	
	free(nodo);
}

hash_t *hash_crear(hash_destruir_dato_t destruir_dato){
	hash_t* nuevo_hash = malloc(sizeof(hash_t));
	if(!nuevo_hash ){
		return NULL;
	}	
	nuevo_hash->tamanio_tabla = HASH_TAM_TABLA;
	nuevo_hash->listas = inicializar_listas(HASH_TAM_TABLA);	
	if(!nuevo_hash->listas){
		return NULL;
	}	
	nuevo_hash->cantidad_elem = 0;
	nuevo_hash->destructor_dato = destruir_dato;
	return nuevo_hash;
}

size_t hash_cantidad(const hash_t *hash){	
	return hash->cantidad_elem;
}



//Redimensiona el hash al nuevo tamanio pasado por parametro
//PRE: El tamanio es siempre mayor a cero y el hash fue creado correctamente
//POS: devuelve true si se redimensiono correctamente, o false si fallo
bool hash_redimensionar(hash_t* hash, size_t nuevo_tam){
	if(nuevo_tam < HASH_TAM_TABLA){ // si nuevo tamaño es menor al tamaño inicial no redimensionamos
		return true;
	}	
	lista_t** nueva_tabla = inicializar_listas(nuevo_tam);
	if(!nueva_tabla){
		return false;
	}
	for(int i = 0;i<hash->tamanio_tabla;i++){
		lista_t* lista = hash->listas[i];
		while(!lista_esta_vacia(lista)){
			hash_nodo_t* node = lista_borrar_primero(lista);
			char* clave = node->clave;
			long unsigned int new_pos = (long unsigned int) hashing(clave,nuevo_tam);
			lista_t* lista_a = nueva_tabla[new_pos];
			lista_insertar_ultimo(lista_a,node);
		}
		lista_destruir(hash->listas[i],NULL);
	}	
	lista_t** tabla_anterior = hash->listas;
	free(tabla_anterior);
	hash->listas = nueva_tabla;	
	hash->tamanio_tabla = nuevo_tam;		
	return true;
}

bool hash_guardar(hash_t *hash, const char *clave, void *dato){ 
	double fact_carga = (double) hash->cantidad_elem/  (double)hash->tamanio_tabla;
	if(fact_carga >= FACTOR_CARGA_SUP && fact_carga<1){ 
		if(!hash_redimensionar(hash,(hash->tamanio_tabla)*FACTOR_REDIMENSION_SUP)){
			return false;
		}
	}
	if(hash_pertenece(hash,clave)){
		void* dato_aux = hash_borrar(hash,clave);
		if(hash->destructor_dato != NULL){
			hash->destructor_dato(dato_aux); 
		}		
	}
	hash_nodo_t* nodo =crear_hash_nodo(clave,dato);
	if(nodo == NULL)
		return false;	
	long unsigned int resultado = (long unsigned int) hashing(clave,hash->tamanio_tabla);
	lista_insertar_ultimo(hash->listas[resultado],nodo);
	hash->cantidad_elem++;
	return true;
}
bool hash_pertenece(const hash_t *hash, const char *clave){
	long unsigned int resultado =(long unsigned int) hashing(clave,hash->tamanio_tabla);
	if(lista_esta_vacia(hash->listas[resultado])){ 
		return false;
	}
	lista_iter_t* iter = lista_iter_crear(hash->listas[resultado]);
	if(!iter){
		return false;
	}
	while(!lista_iter_al_final(iter)){
		hash_nodo_t* nodo = lista_iter_ver_actual(iter);
		if(strcmp(nodo->clave,clave)==0){
			lista_iter_destruir(iter);
			return true;
		}
		lista_iter_avanzar(iter);
	}
	lista_iter_destruir(iter);
	return false;		
}

void* hash_borrar(hash_t *hash, const char *clave){
	double fact_carga = (double) hash->cantidad_elem /  (double)hash->tamanio_tabla;
	if(fact_carga <= FACTOR_CARGA_INF && fact_carga>0){		 
		if(!hash_redimensionar(hash,hash->tamanio_tabla/(size_t)FACTOR_REDIMENSION_INF))
			return NULL;					
	}
	bool encontrado = false;
	long unsigned int resultado = (long unsigned int) hashing(clave,hash->tamanio_tabla);
	lista_t* lista = hash->listas[resultado];
	if(lista_esta_vacia(lista)){
		return NULL;
	}
	lista_iter_t* iter = lista_iter_crear(lista);
	if(!iter){
		return NULL;
	}
	hash_nodo_t* nodo;
	void* dato = NULL;
	while(!lista_iter_al_final(iter) && !encontrado ){
		nodo = lista_iter_ver_actual(iter);		
		if(strcmp(nodo->clave,clave)==0){
			lista_iter_borrar(iter);
			dato = nodo->dato;
			hash_nodo_destruir(nodo,NULL);
			hash->cantidad_elem--;
			encontrado = true;
		}else
		lista_iter_avanzar(iter);				
	}
	lista_iter_destruir(iter);	
	return dato; 
}


void* hash_obtener(const hash_t *hash, const char *clave){
	if(hash->cantidad_elem ==0)
		return NULL;		
	long unsigned int resultado = (long unsigned int) hashing(clave,hash->tamanio_tabla);
	if(!lista_esta_vacia(hash->listas[resultado])){
		lista_iter_t* iter = lista_iter_crear(hash->listas[resultado]);
		if(!iter){
			return NULL;
		}
		while(!lista_iter_al_final(iter)){
			hash_nodo_t* nodo = lista_iter_ver_actual(iter);
			if(strcmp(nodo->clave,clave) == 0){
				lista_iter_destruir(iter);
				return nodo->dato;
			}
			lista_iter_avanzar(iter);
		}
	lista_iter_destruir(iter);
	}
	return NULL;
}

void hash_destruir(hash_t *hash){ 
	for(int i = 0;i<hash->tamanio_tabla;i++){
		lista_t* lista_actual = hash->listas[i];
		while(!lista_esta_vacia(lista_actual)){
			hash_nodo_t* nodo = lista_borrar_primero(lista_actual);				
			hash_nodo_destruir(nodo,hash->destructor_dato);	
		}
		lista_destruir(hash->listas[i],NULL);			
	}	
	free(hash->listas);
	free(hash);
}



/* -------------------------- HASH ITERADOR --------------------*/

hash_iter_t *hash_iter_crear(const hash_t *hash){
	hash_iter_t* hash_iter = malloc(sizeof(hash_iter_t));
	if(!hash_iter){
		return NULL; 
	}
	hash_iter->hash = hash;
	hash_iter->lista_actual = 0;
	hash_iter->lista_iter = lista_iter_crear(hash->listas[0]); 
	if(lista_iter_ver_actual(hash_iter->lista_iter) ==NULL){
		hash_iter_avanzar(hash_iter);
	}
	return hash_iter;
}

bool hash_iter_avanzar(hash_iter_t *iter){	
	if(iter->lista_iter == NULL){
		return false;
	}
	if((lista_iter_avanzar(iter->lista_iter)) == false || lista_iter_ver_actual(iter->lista_iter) == NULL){ 
		while(lista_iter_al_final(iter->lista_iter) == true){	
			iter->lista_actual++;
			if(iter->lista_actual < iter->hash->tamanio_tabla){
				if(!lista_esta_vacia((iter->hash->listas[iter->lista_actual]))) {
					lista_iter_t* iterador_auxiliar = iter->lista_iter;					
					lista_iter_destruir(iterador_auxiliar); 
					iter->lista_iter = lista_iter_crear(iter->hash->listas[iter->lista_actual]);
					if(!iter->lista_iter){
						return false;
					}
				}				
			}
			else{
				return false; 
			}		
		}		
	}	
	return true;
}	



/*Devuelve clave actual, esa clave no se puede modificar ni liberar*/
const char *hash_iter_ver_actual(const hash_iter_t *iter){
	
	hash_nodo_t* nodo = lista_iter_ver_actual(iter->lista_iter); 
	if(nodo == NULL){ 
		return NULL;
	}	
	
	return nodo->clave;
}
bool hash_iter_al_final(const hash_iter_t *iter){
	size_t lista_actual =iter->lista_actual; 
	lista_iter_t* iterador_auxiliar = iter->lista_iter;
	while(lista_iter_ver_actual(iterador_auxiliar) == NULL){	 
		lista_actual++; 
		if(lista_actual < iter->hash->tamanio_tabla){ 
			if(!lista_esta_vacia((iter->hash->listas[iter->lista_actual]))) {			
				iterador_auxiliar = lista_iter_crear(iter->hash->listas[lista_actual]);
				if(!iterador_auxiliar){
					return false;
				}
				if(lista_iter_ver_actual(iterador_auxiliar)!= NULL){
					return false;
				}
			}			
		}else{
			return true; 
		}
	}
	return false; 
		

}
void hash_iter_destruir(hash_iter_t* iter){
	lista_iter_destruir(iter->lista_iter);
	free(iter);

}




				
