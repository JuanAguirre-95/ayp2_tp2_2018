#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

size_t contar_palabras(const char* str, char sep){
	size_t cont = 1;
	if(str == NULL)
		return 0;
	for(int i = 0;str[i]!='\0';i++){
		if(str[i]==sep)
			cont++;
	}
	return cont;
}
char* extraer_palabra(const char* str, size_t ini,size_t fin){
	size_t len_pal = fin - ini+1;
	char* palabra = malloc(sizeof(char)*(len_pal));
	if(palabra==NULL)
		return NULL;
		
	if(len_pal == 1){
		palabra[0] = '\0';
		return palabra;
	}
	for(size_t i = 0,j = ini; i<len_pal;i++,j++){
		palabra[i] = str[j];
	}
	palabra[len_pal-1] = '\0';
	return palabra;
}

char** split(const char* str, char sep){
	if(sep == '\0')
		return NULL;
	size_t ini = 0, fin = 0, cant_pal = 0,j = 0,len_str = 0; 
	len_str = strlen(str);
	cant_pal = contar_palabras(str,sep);
	char** lista_pal = malloc((sizeof(char*) * (cant_pal+1)));
	if(lista_pal == NULL)
		return NULL;
	
	for(size_t i = 0;i<len_str+1;i++){
		if(str[i] == sep || str[i] == '\0'){
			fin = i;
			char* palabra = extraer_palabra(str,ini,fin);
			if(palabra==NULL)
				return NULL;
			ini = fin+1;
			if(j<cant_pal){
				lista_pal[j] = palabra;
				j++;
			}
		}
	}
	lista_pal[cant_pal] = NULL;
	//for(int i = 0; i<cant_pal;i++)
	//	printf("|%s|\n",lista_pal[i]);
	return lista_pal;	
}

void free_strv(char* strv[]){
	for(int i = 0;strv[i]!=NULL;i++){
		char* palabra = strv[i];
		free(palabra);
	}
	free(strv);
}
