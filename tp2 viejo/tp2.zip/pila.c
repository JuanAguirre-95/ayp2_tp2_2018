#include "pila.h"
#include <stdlib.h>

#define CAPACIDAD_MIN 10 //podria ser mayor tambien.
#define FACT_AGRANDAR 2
#define FACT_REDUCIR 2


/* Definición del struct pila proporcionado por la cátedra.
 */
struct pila {
    void** datos;
    size_t cantidad;  // Cantidad de elementos almacenados.
    size_t capacidad;  // Capacidad del arreglo 'datos'.
};


//Redimensiona la pila usando realloc
//PRE: recibe una pila, y el nuevo tamanio
//POST: devuelve false si algo falla, true si se modifico el tamanio correctamente
bool pila_redimensionar(pila_t* pila, size_t nuevo_tam){
	void** nuevo_datos = realloc(pila->datos,nuevo_tam * sizeof(void*)); 
	if(nuevo_tam < CAPACIDAD_MIN && nuevo_datos == NULL)
		return false;
	pila->datos = nuevo_datos;
	pila->capacidad = nuevo_tam;
	
	return true;
}

/* *****************************************************************
 *                    PRIMITIVAS DE LA PILA
 * *****************************************************************/

pila_t* pila_crear(void){
	pila_t* pila = malloc(sizeof(pila_t));
	if (pila==NULL)
		return NULL;	
	pila->datos = malloc(CAPACIDAD_MIN*sizeof(void*));
	if(pila->datos == NULL){
		free(pila);
		return NULL;
	}
	pila->cantidad = 0;
    pila->capacidad = CAPACIDAD_MIN;
	return pila;
}
void pila_destruir(pila_t *pila){
	free(pila->datos);
	free(pila);
}
bool pila_esta_vacia(const pila_t *pila){
	return pila->cantidad==0;
}
bool pila_apilar(pila_t *pila, void* valor){
	if(pila->cantidad == pila->capacidad)
		if(!pila_redimensionar(pila,pila->capacidad * FACT_AGRANDAR))
			return false;				
	pila->datos[pila->cantidad] =valor; 
	pila->cantidad++;
	return true;
}
	

void* pila_ver_tope(const pila_t *pila){
	if(pila_esta_vacia(pila)){
		return NULL;							
	}
	return pila->datos[pila->cantidad-1];
	
}
void* pila_desapilar(pila_t *pila){
	if(pila_esta_vacia(pila))
		return NULL;
	if(pila->cantidad < ((int)(pila->capacidad/(2*FACT_REDUCIR))) && pila->cantidad >CAPACIDAD_MIN)
		pila_redimensionar(pila,pila->capacidad/FACT_REDUCIR);
	pila->cantidad--;
	return pila->datos[pila->cantidad];	
}

//MB 
