#define _POSIX_C_SOURCE 200809L  // Para strdup() y getline
#define _XOPEN_SOURCE
#include <time.h>
#define TIME_FORMAT "%FT%T%z"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "strutil.h"
#include "hash.h"
#include "abb.h"
#include "heap.h"
#include "lista.h"
#include "analog.h"

int main(int argc,char* argv[]){
	if(argc >= 2)
		return 0;
    int errores_tipo2 = 0;

	abb_t* arbol_ips = abb_crear(comparar_ips,NULL);
	hash_t* hash_urls = hash_crear(visita_destruir_wrapper);
	
	char* linea = NULL; size_t size = 0; ssize_t leidos;
	while((leidos  = getline(&linea,&size,stdin))>0){
		linea[leidos-1] = '\0';
		char** comand = split(linea,' ');
		errores_tipo2 = interfaz(comand,arbol_ips,hash_urls);
		
		if(errores_tipo2){
			break;
		}
	}
	free(linea);
	abb_destruir(arbol_ips);
	hash_destruir(hash_urls);
	return 0;
}
	
