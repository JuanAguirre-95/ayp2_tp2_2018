#ifndef HASHING_H
#define HASHING_H
#include <stdio.h>
#include <stdlib.h>

size_t hashing(const char* clave, size_t capacidad);
#endif //HASHING_H



